<template>
    <section class="user-dashboard">
        <!-- Loading -->
        <loading :active.sync="isLoading"
                 :is-full-page="fullPage"></loading>
        <div class="dashboard-outer">
            <div class="upper-title-box">
                <h3>Portfolio</h3>
                <div class="text">Ready to jump back in?</div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Ls widget -->
                    <div class="ls-widget">
                        <div class="tabs-box">
                            <div class="widget-title">
                                <h4>Add new photos</h4>
                            </div>

                            <div class="widget-content">
                                <form class="default-form">
                                    <div class="row">
                                        <div class="uploading-outer">
                                            <div class="uploadButton">
                                                <input class="uploadButton-input"
                                                       type="file"
                                                       id="upload"
                                                       ref="files"
                                                       @change="uploadImages($event)"
                                                       multiple
                                                />
                                                <label class="uploadButton-button ripple-effect" for="upload">Browse
                                                    Image</label>
                                                <span class="uploadButton-file-name"></span>
                                            </div>
                                            <div class="text">Max file size is 1MB, Minimum dimension: 330x300 And
                                                Suitable files are .jpg & .png
                                            </div>
                                        </div>
                                        <div class="preview" v-if="preview.length > 0">
                                            <img v-for="img in preview" :src="img">
                                        </div>
                                        <div class="w-100 text-right p-2" v-if="preview.length > 0">
                                            <button type="button" class="btn btn-success" @click="addPortfolio">
                                                <i class="fa fa-check"></i>
                                                Save
                                            </button>
                                            <button type="button" class="btn btn-link" @click="preview = [],images = []">
                                                Clear images
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Ls widget -->
                    <div class="ls-widget">
                        <div class="tabs-box">
                            <div class="widget-title">
                                <h4>My portfolio</h4>
                            </div>
                            <div class="widget-content">
                                <form class="default-form">
                                    <div class="row" v-if="portfolio.length > 0">
                                        <div class="col-6 col-md-3 mt-3"
                                             v-for="(port, index) in portfolio"
                                             :key="port.id">
                                            <img :src="'/images/portfolio/' + port.image" class="w-100">
                                            <div class="text-center my-2">
                                                <button type="button"
                                                        class="btn btn-danger btn-sm"
                                                        @click="modals.delete=true,x=index">
                                                    <i class="fa fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" v-else>
                                        <div class="col-12">
                                            <p class="text-center">No images added yet.</p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="overlay" v-if="loading">
            <i class="fa fa-spin fa-spinner"></i>
        </div>
        <Modal v-model="modals.delete" title="Are you sure?">
            <div class="modal-body">
                Are you sure delete?
            </div>
            <div class="modal-footer">
                <button class="btn btn-danger" @click="deletePortfolio(x)">Yes</button>
                <button class="btn btn-secondary" @click="modals.delete=false">Cancel</button>
            </div>
        </Modal>
    </section>
</template>

<script>
import Loading from 'vue-loading-overlay';
import 'vue-loading-overlay/dist/vue-loading.css';
export default {
    components: {Loading},
    mounted() {
        document.title = "Dashboard - Portfolio"
        axios.get("/request/profile/get-portfolio")
        .then((res) => {
            this.portfolio = res.data
        })
    },
    data: function () {
        return {
            images: [],
            preview: [],
            portfolio: [],
            loading: false,
            modals: {
                delete: false
            },
            isLoading: false,
            fullPage: true
        }
    },
    methods: {
        uploadImages: function (e) {
            let i = 0,
                j = 0,
                s = e.target.files.length
            for(i; i < s; i++) {
                this.preview.push(URL.createObjectURL(e.target.files[i]))
            }
            this.images = e.target.files
        },
        addPortfolio: function () {
            this.loading = true
            const fd = new FormData();
            for(let i = 0; i < this.images.length; i++) {
                fd.append('files[' + i + ']', this.images[i])
            }
            // console.log(fd)
            axios({
                method: "post",
                url: "/request/profile/add-portfolio",
                data: fd,
                headers: {"Content-Type": "multipart/form-data"},
            })
            .then((res) => {
                this.images = []
                this.preview = []
                for(let i = 0; i < res.data.length; i++) {
                    this.portfolio.unshift(res.data[i])
                }
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'success',
                    title: 'Added successfully'
                })
                this.loading = false
            })
        },
        deletePortfolio: function (index) {
            axios.post("/request/profile/delete-portfolio", {
                id: this.portfolio[index].id
            })
            .then((res) => {
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                })

                Toast.fire({
                    icon: 'success',
                    title: 'Deleted successfully'
                })
                this.portfolio.splice(index, 1)
                this.modals.delete = false
            })
        }
    }
}
</script>

<style>
.preview img {
    width: 120px;
    height: 120px;
    margin: 12px;
    border-radius: 5px;
}
.overlay {
    position: fixed;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.7);
    top: 0;
    left: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1;
}
.overlay i {
    color: #fff;
    font-size: 40px;
}
</style>
