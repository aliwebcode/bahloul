<template>
    <div>
        <div class="row" style="margin-top: 80px">
            <div class="col-12 text-center">
                <img src="/assets/images/404.svg" alt="Not Found">
            </div>
            <div class="col-12 text-center my-5">
                <h5>Are you lost? <a href="/" style="font-size: 16px;">Go Home</a></h5>
            </div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
img {
    width: 400px;
}
</style>