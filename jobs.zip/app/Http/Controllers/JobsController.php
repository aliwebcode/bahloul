<?php

namespace App\Http\Controllers;

use App\Category;
use App\City;
use App\Country;
use App\Job;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;

class JobsController extends Controller
{
    public function get_user_jobs()
    {
        $data = User::with(['jobs', 'jobs.category', 'jobs.applicants', 'jobs.country', 'jobs.city'])->find(auth()->id());
        return response()->json($data);
    }

    public function get_add_job()
    {
        $user = auth()->user();
        $countries = Country::all();
        $cities = City::all();
        $categories = Category::all();
        return response()->json([
            "user" => $user,
            "countries" => $countries,
            "cities" => $cities,
            "categories" => $categories
        ]);
    }

    public function get_cities($id)
    {
        $cities = City::where('country_id', $id)->get();
        return response()->json($cities);
    }

    public function add(Request $request)
    {
        $data = $request->job;
        $data['user_id'] = auth()->id();
        Job::create($data);
        return response()->json(1, 200);
    }

    public function show($id)
    {
        $job = Job::with([
            'category', 'country', 'city', 'user', 'user.country', 'user.city', 'applicants'
        ])->find($id);
        return response()->json(["job" => $job, "user" => auth()->user()]);
    }

    public function get_jobs()
    {
//        $country = "";
//        $city = "";
//        if(\request()->location != null) {
//            $country = Country::where('name', 'like', '%' . \request()->location . '%')->first();
//            $country ? $country = $country->id : $country = "a";
//            $city = City::where('name', 'like', '%' . \request()->location . '%')->first();
//            $city ? $city = $city->id : $city = "a";
//        }
        $jobs = Job::when(\request()->title != null, function ($q) {
                $q->where('title', 'like', '%' . \request()->title . '%');
            })
            ->when(\request()->type != null, function ($q) {
                $q->where('type', \request()->type);
            })
            ->when(\request()->country_id != null, function ($q) {
                $q->where('country_id', \request()->country_id);
            })
            ->when(\request()->city_id != null, function ($q) {
                $q->where('city_id', \request()->city_id);
            })
            ->when(\request()->category_id != null, function ($q) {
                $q->where('category_id', \request()->category_id);
            })
            ->when(\request()->date != null, function ($q) {
                $q->where('created_at', '>=', Carbon::now()->subDays(\request()->date));
            });
        $jobs = $jobs->with(['user', 'country', 'city', 'category', 'applicants'])->get();
        if(\request()->all()) {
            return response()->json(["jobs" => $jobs]);
        }

        $countries = Country::all();
        $categories = Category::all();

        return response()->json(["jobs" => $jobs, "categories" => $categories, "countries" => $countries]);
    }

    public function job_filter(Request $request)
    {
        // Global
        $title = $request->data['title'] ?? "";
        $type = $request->data['type'] ?? "";
        $location = $request->data['location'] ?? "";
        $category_id = $request->data['category_id'] ?? "";
        $date = $request->data['date'] ?? "";

        // Get Filtered Data
        $jobs = Job::query()->with(['user', 'country', 'city', 'category', 'applicants']);
        if($location && $jobs->count() > 0) {
            $jobs = $jobs->whereHas('country', function ($q) use ($location) {
                $q->where('name', 'like', '%' . $location . '%');
            })->orWhereHas('city', function ($q) use ($location) {
                $q->where('name', 'like', '%' . $location . '%');
            });
        }
        if($title) {
            $jobs = $jobs->where('title', 'like', '%' . $title . '%')
            ->orWhereHas('user', function ($q) use ($title) {
                $q->where('name', 'like', '%' . $title . '%');
            });
        }
        if($type) {
            $jobs = $jobs->where('type', $type);
        }
        if($category_id) {
            $jobs = $jobs->where('category_id', $category_id);
        }
        if($date) {
            $d = Carbon::now()->subDays($date);
            $jobs = $jobs->where('created_at', '>=', $d);
        }
        $results = $jobs->get();
        return response()->json($results);
    }

}
