<?php

namespace App\Http\Controllers;

use App\Portfolio;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class PortfolioController extends Controller
{

    public function get() {
        $user = auth()->user();
        return response()->json($user->user_portfolio);
    }

    public function add(Request $request) {
        if ($request->hasFile('files')) {
            $files = $request->file('files');
            $data = [];
            foreach ($files as $file) {
                $filename = $file->getClientOriginalName();
                $newName = uniqid() . '-' . now()->timestamp . $filename;
                $file->move('images/portfolio/', $newName);
                // Save Records
                $row = new Portfolio();
                $row->user_id = auth()->id();
                $row->image = $newName;
                $row->save();
                $data[] = $row;
            }
            return response()->json($data);
        }
    }

    public function delete(Request $request) {
        $port = Portfolio::find($request->id);
        if(File::exists('images/portfolio/' . $port->image)) {
            File::delete('images/portfolio/' . $port->image);
        }
        $port->delete();
        return response()->json(1,200);
    }
}
